#include "librti.h"
#include <stdio.h>

int main(){
  int x;
  
  printf("Hello World");
  x=foo(3);
  printf("foo result %d",x);
  return 0;
}
