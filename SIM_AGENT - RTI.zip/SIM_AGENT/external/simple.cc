
/*extern "C" int inc(int);*/



#include "/home/mhl/rti/RTI-1.3NGv4/Linux-rh62-i386-egcs-2.91.66-opt-mt/include/RTI.hh"

int inc(int x){
  return x+1;
}
