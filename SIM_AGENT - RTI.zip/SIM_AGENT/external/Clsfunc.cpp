#include "classdef.h"
#include <stdio.h>

void CVehicle::printdata()
{
  printf("Weight: %u, Capacity: %u, Top speed: %f\n",weight,capacity,topspeed);
}
