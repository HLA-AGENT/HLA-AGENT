#ifndef CLASS_VEHICLE
#define CLASS_VEHICLE

class CVehicle
{
 private:
  unsigned int weight, capacity;
  float topspeed;

 public:
  void printdata();
};

#endif
