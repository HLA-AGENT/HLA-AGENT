#include "classdef.h"

int main()
{
  CVehicle mycar;

  mycar.printdata();

  return 0;
}
  
